export type Payment = {
  id: string;
  bookingId: string;
  type: 'client' | 'supplier';
  date: string;
  amount: number;
  currency: string;
  method: string;
  notes?: string | null;
};

export type Client = {
  id: string; code: string; name: string; phone?: string | null; currency: string; notes?: string | null;
};

export type Supplier = {
  id: string; code: string; name: string; type: string; currency: string; notes?: string | null;
};

export type Booking = {
  id: string; number: string; date: string; serviceType: string; status: string;
  clientId?: string | null; client?: Client | null;
  supplierId?: string | null; supplier?: Supplier | null;
  saleAmount: number; saleCurrency: string;
  purchaseAmount: number; purchaseCurrency: string;
  notes?: string | null;
  payments: Payment[];
};

export function clientPayments(b: Booking) { return b.payments.filter(p => p.type === 'client'); }
export function supplierPayments(b: Booking) { return b.payments.filter(p => p.type === 'supplier'); }
export function bookingSalePaid(b: Booking) { return clientPayments(b).reduce((s, p) => s + Number(p.amount || 0), 0); }
export function bookingPurchasePaid(b: Booking) { return supplierPayments(b).reduce((s, p) => s + Number(p.amount || 0), 0); }

// ===== كشف الحساب (دفتر الأستاذ): مدين / دائن / رصيد =====
export type LedgerEntry = { date: string; desc: string; debit: number; credit: number };

function pushEntry(map: Record<string, LedgerEntry[]>, cur: string, e: LedgerEntry) {
  (map[cur] = map[cur] || []).push(e);
}

/** كشف حساب العميل: كل حجز = مدين (عليه)، كل تحصيل = دائن (له). مجمّع حسب العملة. */
export function clientLedger(bookings: Booking[], clientId: string): Record<string, LedgerEntry[]> {
  const map: Record<string, LedgerEntry[]> = {};
  bookings.filter((b) => b.clientId === clientId).forEach((b) => {
    pushEntry(map, b.saleCurrency, { date: b.date, desc: `حجز ${b.number} - ${b.serviceType}`, debit: Number(b.saleAmount || 0), credit: 0 });
    clientPayments(b).forEach((p) => {
      pushEntry(map, p.currency, { date: p.date, desc: `تحصيل (${p.method}) - حجز ${b.number}`, debit: 0, credit: Number(p.amount || 0) });
    });
  });
  Object.values(map).forEach((arr) => arr.sort((a, b) => a.date.localeCompare(b.date)));
  return map;
}

/** كشف حساب المورد: كل حجز = مدين (علينا)، كل دفعة له = دائن (سددناها). مجمّع حسب العملة. */
export function supplierLedger(bookings: Booking[], supplierId: string): Record<string, LedgerEntry[]> {
  const map: Record<string, LedgerEntry[]> = {};
  bookings.filter((b) => b.supplierId === supplierId).forEach((b) => {
    pushEntry(map, b.purchaseCurrency, { date: b.date, desc: `حجز ${b.number} - ${b.serviceType}`, debit: Number(b.purchaseAmount || 0), credit: 0 });
    supplierPayments(b).forEach((p) => {
      pushEntry(map, p.currency, { date: p.date, desc: `دفعة (${p.method}) - حجز ${b.number}`, debit: 0, credit: Number(p.amount || 0) });
    });
  });
  Object.values(map).forEach((arr) => arr.sort((a, b) => a.date.localeCompare(b.date)));
  return map;
}

/** صافي الرصيد لكل عملة: مدين - دائن */
export function ledgerDues(ledger: Record<string, LedgerEntry[]>): { cur: string; amt: number }[] {
  return Object.entries(ledger).map(([cur, arr]) => ({ cur, amt: arr.reduce((s, e) => s + e.debit - e.credit, 0) }));
}

export type PayStatus = 'owe' | 'credit' | 'settled' | 'none';
/** حالة السداد: owe = عليه مستحق (أحمر) | credit = له رصيد زيادة (أزرق) | settled = مسدد بالكامل (أخضر) | none = لا يوجد حجوزات */
export function payStatus(dues: { cur: string; amt: number }[], hasBookings: boolean): PayStatus {
  if (!hasBookings) return 'none';
  if (dues.some((d) => d.amt > 0.01)) return 'owe';
  if (dues.some((d) => d.amt < -0.01)) return 'credit';
  return 'settled';
}
