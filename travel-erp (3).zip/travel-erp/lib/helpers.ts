export const CURRENCIES = ['EGP', 'USD', 'SAR'];
export const CUR_SYMBOL: Record<string, string> = { EGP: 'ج.م', USD: '$', SAR: 'ر.س' };
export const SERVICE_TYPES = ['تذكرة طيران', 'فندق', 'تأشيرة', 'نقل', 'عمرة', 'باقة سياحية', 'خدمة أخرى'];
export const SUPPLIER_TYPES = ['شركة طيران', 'فندق', 'شركة نقل', 'وكيل سياحي', 'شركة تأشيرات', 'مورد آخر'];
export const PAY_METHODS = ['نقدي', 'تحويل بنكي', 'بطاقة', 'أخرى'];
export const STATUSES = ['جديد', 'مؤكد', 'مدفوع جزئياً', 'مدفوع بالكامل', 'ملغي', 'مسترجع'];
export const STATUS_BADGE: Record<string, string> = {
  'جديد': 'badge-new',
  'مؤكد': 'badge-confirmed',
  'مدفوع جزئياً': 'badge-partial',
  'مدفوع بالكامل': 'badge-paid',
  'ملغي': 'badge-cancel',
  'مسترجع': 'badge-return',
};

export function fmt(n: number) {
  return (Number(n) || 0).toLocaleString('en-US', { maximumFractionDigits: 2 });
}
export function money(n: number, cur: string) {
  return `${fmt(n)} ${CUR_SYMBOL[cur] || cur}`;
}
export function fmtDate(d: string | Date | null | undefined) {
  if (!d) return '—';
  const date = typeof d === 'string' ? d.slice(0, 10) : new Date(d).toISOString().slice(0, 10);
  const p = date.split('-');
  return p.length === 3 ? `${p[2]}/${p[1]}/${p[0]}` : date;
}
