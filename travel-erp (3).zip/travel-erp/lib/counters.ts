import { prisma } from './prisma';

export async function nextCode(key: 'client' | 'supplier' | 'booking', prefix: string) {
  const counter = await prisma.counter.upsert({
    where: { key },
    update: { value: { increment: 1 } },
    create: { key, value: 1 },
  });
  return prefix + String(counter.value).padStart(4, '0');
}
