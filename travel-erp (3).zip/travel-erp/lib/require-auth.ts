import { getSessionFromCookies } from './auth';
import { NextResponse } from 'next/server';

export async function requireAuth() {
  const ok = await getSessionFromCookies();
  if (!ok) {
    return NextResponse.json({ error: 'غير مصرح، الرجاء تسجيل الدخول' }, { status: 401 });
  }
  return null;
}
