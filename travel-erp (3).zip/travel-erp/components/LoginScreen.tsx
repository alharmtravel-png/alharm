'use client';
import { useState } from 'react';
import { api } from '@/lib/api';

export default function LoginScreen({ firstRun, onAuthed }: { firstRun: boolean; onAuthed: (companyName: string) => void }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const data = await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ password }) });
      onAuthed(data.companyName);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-wrap">
      <div className="auth-card">
        <div className="auth-mark">🧾</div>
        <h1>{firstRun ? 'إعداد النظام لأول مرة' : 'نظام محاسبة السياحة والسفر'}</h1>
        <p>{firstRun ? 'اختر كلمة مرور لحماية النظام' : 'أدخل كلمة المرور للدخول'}</p>
        {error && <div className="error-msg">{error}</div>}
        <form onSubmit={submit}>
          <div className="field">
            <label>كلمة المرور</label>
            <input
              type="password"
              required
              minLength={3}
              autoFocus
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button className="btn btn-primary" style={{ width: '100%' }} type="submit" disabled={loading}>
            {loading ? '...' : firstRun ? 'بدء الاستخدام' : 'دخول'}
          </button>
        </form>
        {firstRun && <div className="auth-foot">يمكنك تغيير كلمة المرور لاحقًا من الإعدادات</div>}
      </div>
    </div>
  );
}
