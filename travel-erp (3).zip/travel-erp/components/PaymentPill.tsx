export default function PaymentPill({ type }: { type: 'client' | 'supplier' }) {
  return (
    <span className={`pill ${type === 'client' ? 'pill-client' : 'pill-supplier'}`}>
      {type === 'client' ? 'تحصيل من العميل' : 'دفع للمورد'}
    </span>
  );
}
