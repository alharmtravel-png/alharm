import { STATUS_BADGE } from '@/lib/helpers';

export default function StatusBadge({ status }: { status: string }) {
  return <span className={`badge ${STATUS_BADGE[status] || 'badge-new'}`}>{status}</span>;
}
