'use client';
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { showToast } from './Toast';

export default function SettingsTab({ onCompanyNameChange }: { onCompanyNameChange: (n: string) => void }) {
  const [sub, setSub] = useState<'general' | 'security'>('general');
  const [companyName, setCompanyName] = useState('');
  const [pwForm, setPwForm] = useState({ currentPassword: '', newPassword: '' });
  const [pwError, setPwError] = useState('');

  useEffect(() => { api('/api/settings').then((d) => setCompanyName(d.companyName || '')).catch(() => {}); }, []);

  async function saveGeneral(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api('/api/settings', { method: 'PUT', body: JSON.stringify({ companyName }) });
      onCompanyNameChange(companyName);
      showToast('تم الحفظ');
    } catch (e: any) { showToast(e.message); }
  }

  async function savePassword(e: React.FormEvent) {
    e.preventDefault();
    setPwError('');
    try {
      await api('/api/settings', { method: 'PUT', body: JSON.stringify(pwForm) });
      showToast('تم تحديث كلمة المرور');
      setPwForm({ currentPassword: '', newPassword: '' });
    } catch (e: any) { setPwError(e.message); }
  }

  return (
    <div>
      <h2 className="section-title">الإعدادات</h2>
      <div className="filters" style={{ marginBottom: 16 }}>
        <button className={`chip ${sub === 'general' ? 'active' : ''}`} onClick={() => setSub('general')}>عام</button>
        <button className={`chip ${sub === 'security' ? 'active' : ''}`} onClick={() => setSub('security')}>الأمان</button>
      </div>

      {sub === 'general' && (
        <div className="card card-pad" style={{ maxWidth: 420 }}>
          <h3 style={{ marginTop: 0, fontSize: 15 }}>بيانات الشركة</h3>
          <form onSubmit={saveGeneral}>
            <div className="field"><label>اسم الشركة</label><input value={companyName} onChange={(e) => setCompanyName(e.target.value)} required /></div>
            <button className="btn btn-primary" type="submit">حفظ</button>
          </form>
        </div>
      )}

      {sub === 'security' && (
        <div className="card card-pad" style={{ maxWidth: 420 }}>
          <h3 style={{ marginTop: 0, fontSize: 15 }}>تغيير كلمة المرور</h3>
          {pwError && <div className="error-msg">{pwError}</div>}
          <form onSubmit={savePassword}>
            <div className="field"><label>كلمة المرور الحالية</label><input type="password" required value={pwForm.currentPassword} onChange={(e) => setPwForm({ ...pwForm, currentPassword: e.target.value })} /></div>
            <div className="field"><label>كلمة المرور الجديدة</label><input type="password" required minLength={3} value={pwForm.newPassword} onChange={(e) => setPwForm({ ...pwForm, newPassword: e.target.value })} /></div>
            <button className="btn btn-primary" type="submit">تحديث</button>
          </form>
        </div>
      )}
    </div>
  );
}
