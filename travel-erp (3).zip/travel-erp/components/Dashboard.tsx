'use client';
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { Booking } from '@/lib/types';
import { fmt, money } from '@/lib/helpers';
import StatusBadge from './StatusBadge';
import PaymentPill from './PaymentPill';

export default function Dashboard() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api('/api/bookings').then((data) => { setBookings(data); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  if (loading) return <div className="empty">جارِ التحميل…</div>;

  const today = new Date().toISOString().slice(0, 10);
  const monthKey = today.slice(0, 7);
  const activePeriod = bookings.filter((b) => b.status !== 'ملغي' && b.date.slice(0, 7) === monthKey);

  const sales: Record<string, number> = {};
  const purchases: Record<string, number> = {};
  const collected: Record<string, number> = {};
  const paidOut: Record<string, number> = {};
  activePeriod.forEach((b) => {
    sales[b.saleCurrency] = (sales[b.saleCurrency] || 0) + Number(b.saleAmount || 0);
    purchases[b.purchaseCurrency] = (purchases[b.purchaseCurrency] || 0) + Number(b.purchaseAmount || 0);
    b.payments.forEach((p) => {
      if (p.type === 'client') collected[p.currency] = (collected[p.currency] || 0) + Number(p.amount || 0);
      else paidOut[p.currency] = (paidOut[p.currency] || 0) + Number(p.amount || 0);
    });
  });

  function kpi(title: string, map: Record<string, number>, accent = false) {
    const keys = Object.keys(map);
    return (
      <div className={`kpi-card ${accent ? 'accent' : ''}`}>
        <div className="kpi-label">{title}</div>
        {keys.length ? keys.map((c) => <div key={c} className="kpi-row"><span>{c}</span><b>{fmt(map[c])}</b></div>)
          : <div className="kpi-row"><span>—</span></div>}
      </div>
    );
  }

  const recentBookings = [...bookings].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6);
  const recentPayments = bookings.flatMap((b) => b.payments.map((p) => ({ ...p, bookingNumber: b.number })))
    .sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6);

  return (
    <div>
      <h2 className="section-title">لوحة التحكم</h2>
      <div className="section-sub">ملخص الشهر الحالي ({monthKey})</div>
      <div className="kpi-grid">
        {kpi('إجمالي المبيعات', sales, true)}
        {kpi('إجمالي المشتريات', purchases)}
        {kpi('المحصّل من العملاء', collected)}
        {kpi('المدفوع للموردين', paidOut)}
      </div>

      <div className="card card-pad" style={{ marginBottom: 16 }}>
        <h3 className="section-title" style={{ fontSize: 16 }}>آخر الحجوزات</h3>
        {recentBookings.length === 0 ? <div className="empty">لا توجد حجوزات بعد</div> : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>رقم الحجز</th><th>التاريخ</th><th>الخدمة</th><th>العميل</th><th>الحالة</th></tr></thead>
              <tbody>
                {recentBookings.map((b) => (
                  <tr key={b.id}>
                    <td>{b.number}</td><td>{b.date.slice(0, 10)}</td><td>{b.serviceType}</td>
                    <td>{b.client?.name || '-'}</td><td><StatusBadge status={b.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="card card-pad">
        <h3 className="section-title" style={{ fontSize: 16 }}>آخر عمليات التحصيل والدفع</h3>
        {recentPayments.length === 0 ? <div className="empty">لا توجد عمليات بعد</div> : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>النوع</th><th>المبلغ</th><th>رقم الحجز</th><th>التاريخ</th></tr></thead>
              <tbody>
                {recentPayments.map((p) => (
                  <tr key={p.id}>
                    <td><PaymentPill type={p.type as any} /></td>
                    <td>{money(p.amount, p.currency)}</td>
                    <td>{p.bookingNumber}</td>
                    <td>{p.date.slice(0, 10)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
