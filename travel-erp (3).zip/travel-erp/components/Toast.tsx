'use client';
import { useEffect, useState } from 'react';

let pushToastFn: ((msg: string) => void) | null = null;
export function showToast(msg: string) {
  pushToastFn?.(msg);
}

export default function Toast() {
  const [msg, setMsg] = useState('');
  const [show, setShow] = useState(false);

  useEffect(() => {
    pushToastFn = (m: string) => {
      setMsg(m);
      setShow(true);
      setTimeout(() => setShow(false), 2200);
    };
    return () => { pushToastFn = null; };
  }, []);

  return <div className={`toast ${show ? 'show' : ''}`}>{msg}</div>;
}
