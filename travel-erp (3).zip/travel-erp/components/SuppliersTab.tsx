'use client';
import { useEffect, useMemo, useState } from 'react';
import { api } from '@/lib/api';
import { Booking, Supplier, supplierLedger, ledgerDues, payStatus, PayStatus } from '@/lib/types';
import { CURRENCIES, SUPPLIER_TYPES, fmt } from '@/lib/helpers';
import Modal from './Modal';
import StatementModal from './StatementModal';
import { showToast } from './Toast';

const STATUS_LABEL: Record<PayStatus, string> = {
  owe: 'مستحق له',
  credit: 'دفعنا زيادة',
  settled: 'مسدد بالكامل',
  none: 'لا يوجد حجوزات',
};
const STATUS_BADGE: Record<PayStatus, string> = {
  owe: 'badge-owe', credit: 'badge-credit', settled: 'badge-settled', none: 'badge-nodata',
};

export default function SuppliersTab() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<Supplier | null | undefined>(undefined);
  const [statementFor, setStatementFor] = useState<Supplier | null>(null);
  const [form, setForm] = useState({ name: '', type: SUPPLIER_TYPES[0], currency: 'EGP', notes: '' });

  function load() {
    api('/api/suppliers').then(setSuppliers).catch(() => {});
    api('/api/reports').then((d) => setBookings(d.bookings)).catch(() => {});
  }
  useEffect(load, []);

  function openForm(s?: Supplier) {
    setEditing(s || null);
    setForm(s ? { name: s.name, type: s.type, currency: s.currency, notes: s.notes || '' } : { name: '', type: SUPPLIER_TYPES[0], currency: 'EGP', notes: '' });
  }

  async function save() {
    try {
      if (editing) await api(`/api/suppliers/${editing.id}`, { method: 'PUT', body: JSON.stringify(form) });
      else await api('/api/suppliers', { method: 'POST', body: JSON.stringify(form) });
      showToast('تم الحفظ');
      setEditing(undefined);
      load();
    } catch (e: any) { showToast(e.message); }
  }

  async function remove(s: Supplier) {
    if (!confirm(`حذف المورد "${s.name}"؟`)) return;
    try { await api(`/api/suppliers/${s.id}`, { method: 'DELETE' }); showToast('تم الحذف'); load(); }
    catch (e: any) { showToast(e.message); }
  }

  const ledgerBySupplier = useMemo(() => {
    const map: Record<string, ReturnType<typeof supplierLedger>> = {};
    suppliers.forEach((s) => { map[s.id] = supplierLedger(bookings, s.id); });
    return map;
  }, [suppliers, bookings]);

  function statusOf(s: Supplier): PayStatus {
    const hasBookings = bookings.some((b) => b.supplierId === s.id);
    return payStatus(ledgerDues(ledgerBySupplier[s.id] || {}), hasBookings);
  }

  function dueLine(s: Supplier) {
    const dues = ledgerDues(ledgerBySupplier[s.id] || {}).filter((d) => Math.abs(d.amt) > 0.01);
    if (!dues.length) return '-';
    return dues.map((d) => `${d.amt > 0 ? '+' : ''}${fmt(d.amt)} ${d.cur}`).join(' / ');
  }

  const list = suppliers.filter((s) => s.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      <div className="toolbar">
        <div>
          <h2 className="section-title">الموردين</h2>
          <div className="section-sub mb0">إدارة بيانات الموردين وأرصدتهم</div>
        </div>
        <button className="btn btn-gold" onClick={() => openForm()}>+ مورد جديد</button>
      </div>
      <div className="filters" style={{ marginBottom: 14 }}>
        <input placeholder="ابحث باسم المورد…" value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>
      <div className="card">
        {list.length === 0 ? <div className="empty">لا يوجد موردون بعد</div> : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>الكود</th><th>الاسم</th><th>النوع</th><th>العملة</th><th>حالة السداد</th><th>الرصيد</th><th></th></tr></thead>
              <tbody>
                {list.map((s) => {
                  const st = statusOf(s);
                  return (
                    <tr key={s.id}>
                      <td className="mono">{s.code}</td><td>{s.name}</td><td>{s.type}</td><td>{s.currency}</td>
                      <td>
                        <span className={`badge ${STATUS_BADGE[st]}`}>
                          <span className={`status-dot ${st}`} />{STATUS_LABEL[st]}
                        </span>
                      </td>
                      <td className={st === 'owe' ? 'amt-debit' : st === 'credit' ? 'amt-credit' : ''}>{dueLine(s)}</td>
                      <td>
                        <div className="flex gap8">
                          <button className="btn btn-outline btn-sm" onClick={() => setStatementFor(s)}>كشف حساب</button>
                          <button className="btn btn-outline btn-sm" onClick={() => openForm(s)}>تعديل</button>
                          <button className="btn btn-danger btn-sm" onClick={() => remove(s)}>حذف</button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {editing !== undefined && (
        <Modal title={editing ? 'تعديل مورد' : 'مورد جديد'} onClose={() => setEditing(undefined)}
          actions={[{ label: 'حفظ', cls: 'btn-primary', onClick: save }]}>
          <div className="field"><label>اسم المورد</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div className="two-col">
            <div className="field"><label>النوع</label>
              <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                {SUPPLIER_TYPES.map((t) => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div className="field"><label>العملة</label>
              <select value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value })}>
                {CURRENCIES.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <div className="field"><label>ملاحظات</label><textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
        </Modal>
      )}

      {statementFor && (
        <StatementModal
          name={statementFor.name}
          kind="supplier"
          entriesByCurrency={ledgerBySupplier[statementFor.id] || {}}
          onClose={() => setStatementFor(null)}
        />
      )}
    </div>
  );
}
