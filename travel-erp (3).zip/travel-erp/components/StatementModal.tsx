'use client';
import { useState } from 'react';
import { LedgerEntry } from '@/lib/types';
import { fmt, money, fmtDate } from '@/lib/helpers';

export default function StatementModal({
  name, kind, entriesByCurrency, onClose,
}: {
  name: string;
  kind: 'client' | 'supplier';
  entriesByCurrency: Record<string, LedgerEntry[]>;
  onClose: () => void;
}) {
  const currencies = Object.keys(entriesByCurrency);
  const [cur, setCur] = useState(currencies[0] || 'EGP');
  const entries = entriesByCurrency[cur] || [];

  let running = 0;
  const rows = entries.map((e) => {
    running += e.debit - e.credit;
    return { ...e, balance: running };
  });
  const finalBalance = running;

  const posLabel = kind === 'client' ? 'مستحق على العميل' : 'مستحق للمورد';
  const negLabel = kind === 'client' ? 'رصيد زيادة للعميل' : 'دفعنا أكثر من المستحق';

  return (
    <div className="modal-bg" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal" style={{ maxWidth: 680 }}>
        <div className="modal-head">
          <h3>كشف حساب - {name}</h3>
          <button className="icon-x" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          {currencies.length === 0 ? (
            <div className="empty">لا توجد حركات لهذا {kind === 'client' ? 'العميل' : 'المورد'}</div>
          ) : (
            <>
              {currencies.length > 1 && (
                <div className="filters" style={{ marginBottom: 12 }}>
                  {currencies.map((c) => (
                    <button key={c} className={`chip ${cur === c ? 'active' : ''}`} onClick={() => setCur(c)}>{c}</button>
                  ))}
                </div>
              )}
              {rows.length === 0 ? <div className="empty">لا توجد حركات بهذه العملة</div> : (
                <div className="table-wrap">
                  <table>
                    <thead><tr><th>التاريخ</th><th>البيان</th><th>مدين</th><th>دائن</th><th>الرصيد</th></tr></thead>
                    <tbody>
                      {rows.map((r, i) => (
                        <tr key={i}>
                          <td className="mono">{fmtDate(r.date)}</td>
                          <td>{r.desc}</td>
                          <td className={r.debit ? 'amt-debit' : ''}>{r.debit ? fmt(r.debit) : '-'}</td>
                          <td className={r.credit ? 'amt-credit' : ''}>{r.credit ? fmt(r.credit) : '-'}</td>
                          <td className={r.balance > 0.01 ? 'amt-debit' : r.balance < -0.01 ? 'amt-credit' : 'amt-zero'}>{fmt(r.balance)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              {rows.length > 0 && (
                <>
                  <div className="divider" />
                  <div className="flex" style={{ justifyContent: 'space-between', fontWeight: 800, fontSize: 15 }}>
                    <span>الرصيد النهائي ({cur})</span>
                    <span className={finalBalance > 0.01 ? 'amt-debit' : finalBalance < -0.01 ? 'amt-credit' : 'amt-zero'}>
                      {money(Math.abs(finalBalance), cur)}
                      {' '}
                      ({finalBalance > 0.01 ? posLabel : finalBalance < -0.01 ? negLabel : 'مسدد بالكامل'})
                    </span>
                  </div>
                </>
              )}
            </>
          )}
        </div>
        <div className="modal-foot">
          <button className="btn btn-outline" style={{ flex: 1 }} onClick={onClose}>إغلاق</button>
        </div>
      </div>
    </div>
  );
}
