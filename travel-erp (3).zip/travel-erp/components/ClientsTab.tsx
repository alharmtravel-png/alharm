'use client';
import { useEffect, useMemo, useState } from 'react';
import { api } from '@/lib/api';
import { Booking, Client, clientLedger, ledgerDues, payStatus, PayStatus } from '@/lib/types';
import { CURRENCIES, fmt } from '@/lib/helpers';
import Modal from './Modal';
import StatementModal from './StatementModal';
import { showToast } from './Toast';

const STATUS_LABEL: Record<PayStatus, string> = {
  owe: 'مستحق عليه',
  credit: 'له رصيد',
  settled: 'مسدد بالكامل',
  none: 'لا يوجد حجوزات',
};
const STATUS_BADGE: Record<PayStatus, string> = {
  owe: 'badge-owe', credit: 'badge-credit', settled: 'badge-settled', none: 'badge-nodata',
};

export default function ClientsTab() {
  const [clients, setClients] = useState<Client[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<Client | null | undefined>(undefined);
  const [statementFor, setStatementFor] = useState<Client | null>(null);
  const [form, setForm] = useState({ name: '', phone: '', currency: 'EGP', notes: '' });

  function load() {
    api('/api/clients').then(setClients).catch(() => {});
    api('/api/reports').then((d) => setBookings(d.bookings)).catch(() => {});
  }
  useEffect(load, []);

  function openForm(c?: Client) {
    setEditing(c || null);
    setForm(c ? { name: c.name, phone: c.phone || '', currency: c.currency, notes: c.notes || '' } : { name: '', phone: '', currency: 'EGP', notes: '' });
  }

  async function save() {
    try {
      if (editing) await api(`/api/clients/${editing.id}`, { method: 'PUT', body: JSON.stringify(form) });
      else await api('/api/clients', { method: 'POST', body: JSON.stringify(form) });
      showToast('تم الحفظ');
      setEditing(undefined);
      load();
    } catch (e: any) { showToast(e.message); }
  }

  async function remove(c: Client) {
    if (!confirm(`حذف العميل "${c.name}"؟`)) return;
    try { await api(`/api/clients/${c.id}`, { method: 'DELETE' }); showToast('تم الحذف'); load(); }
    catch (e: any) { showToast(e.message); }
  }

  const ledgerByClient = useMemo(() => {
    const map: Record<string, ReturnType<typeof clientLedger>> = {};
    clients.forEach((c) => { map[c.id] = clientLedger(bookings, c.id); });
    return map;
  }, [clients, bookings]);

  function statusOf(c: Client): PayStatus {
    const hasBookings = bookings.some((b) => b.clientId === c.id);
    return payStatus(ledgerDues(ledgerByClient[c.id] || {}), hasBookings);
  }

  function dueLine(c: Client) {
    const dues = ledgerDues(ledgerByClient[c.id] || {}).filter((d) => Math.abs(d.amt) > 0.01);
    if (!dues.length) return '-';
    return dues.map((d) => `${d.amt > 0 ? '+' : ''}${fmt(d.amt)} ${d.cur}`).join(' / ');
  }

  const list = clients.filter((c) => c.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div>
      <div className="toolbar">
        <div>
          <h2 className="section-title">العملاء</h2>
          <div className="section-sub mb0">إدارة بيانات العملاء وأرصدتهم</div>
        </div>
        <button className="btn btn-gold" onClick={() => openForm()}>+ عميل جديد</button>
      </div>
      <div className="filters" style={{ marginBottom: 14 }}>
        <input placeholder="ابحث باسم العميل…" value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>
      <div className="card">
        {list.length === 0 ? <div className="empty">لا يوجد عملاء بعد</div> : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>الكود</th><th>الاسم</th><th>الهاتف</th><th>العملة</th><th>حالة السداد</th><th>الرصيد</th><th></th></tr></thead>
              <tbody>
                {list.map((c) => {
                  const st = statusOf(c);
                  return (
                    <tr key={c.id}>
                      <td className="mono">{c.code}</td><td>{c.name}</td><td>{c.phone || '-'}</td><td>{c.currency}</td>
                      <td>
                        <span className={`badge ${STATUS_BADGE[st]}`}>
                          <span className={`status-dot ${st}`} />{STATUS_LABEL[st]}
                        </span>
                      </td>
                      <td className={st === 'owe' ? 'amt-debit' : st === 'credit' ? 'amt-credit' : ''}>{dueLine(c)}</td>
                      <td>
                        <div className="flex gap8">
                          <button className="btn btn-outline btn-sm" onClick={() => setStatementFor(c)}>كشف حساب</button>
                          <button className="btn btn-outline btn-sm" onClick={() => openForm(c)}>تعديل</button>
                          <button className="btn btn-danger btn-sm" onClick={() => remove(c)}>حذف</button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {editing !== undefined && (
        <Modal title={editing ? 'تعديل عميل' : 'عميل جديد'} onClose={() => setEditing(undefined)}
          actions={[{ label: 'حفظ', cls: 'btn-primary', onClick: save }]}>
          <div className="field"><label>اسم العميل</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div className="two-col">
            <div className="field"><label>الهاتف</label><input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div className="field"><label>العملة</label>
              <select value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value })}>
                {CURRENCIES.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <div className="field"><label>ملاحظات</label><textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
        </Modal>
      )}

      {statementFor && (
        <StatementModal
          name={statementFor.name}
          kind="client"
          entriesByCurrency={ledgerByClient[statementFor.id] || {}}
          onClose={() => setStatementFor(null)}
        />
      )}
    </div>
  );
}
