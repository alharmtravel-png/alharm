'use client';
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { Booking, Client, Supplier, bookingSalePaid, bookingPurchasePaid } from '@/lib/types';
import { CURRENCIES, SERVICE_TYPES, STATUSES, fmt, money, fmtDate } from '@/lib/helpers';

const REPORT_TYPES = [
  { id: 'sales', label: 'المبيعات' },
  { id: 'purchases', label: 'المشتريات' },
  { id: 'profit', label: 'الأرباح' },
  { id: 'bookings', label: 'الحجوزات' },
  { id: 'clients', label: 'أرصدة العملاء' },
  { id: 'suppliers', label: 'أرصدة الموردين' },
  { id: 'payments', label: 'الدفعات' },
  { id: 'currency', label: 'ملخص العملات' },
];

export default function ReportsTab() {
  const [type, setType] = useState('sales');
  const [filters, setFilters] = useState({ from: '', to: '', clientId: '', supplierId: '', serviceType: '', status: '' });
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);

  useEffect(() => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([k, v]) => v && params.set(k, v));
    api(`/api/reports?${params.toString()}`).then((d) => {
      setBookings(d.bookings);
      setClients(d.clients);
      setSuppliers(d.suppliers);
    }).catch(() => {});
  }, [filters]);

  function exportCSV(headers: string[], rows: (string | number)[][]) {
    let csv = '\uFEFF' + headers.map((h) => `"${h}"`).join(',') + '\n';
    rows.forEach((r) => { csv += r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',') + '\n'; });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${type}-report.csv`; a.click();
    URL.revokeObjectURL(url);
  }

  function getClientName(id?: string | null) { return clients.find((c) => c.id === id)?.name || '-'; }
  function getSupplierName(id?: string | null) { return suppliers.find((s) => s.id === id)?.name || '-'; }

  function clientBalance(clientId: string) {
    const map: Record<string, { sale: number; paid: number }> = {};
    bookings.filter((b) => b.clientId === clientId).forEach((b) => {
      map[b.saleCurrency] = map[b.saleCurrency] || { sale: 0, paid: 0 };
      map[b.saleCurrency].sale += Number(b.saleAmount || 0);
      map[b.saleCurrency].paid += bookingSalePaid(b);
    });
    return map;
  }
  function supplierBalance(supplierId: string) {
    const map: Record<string, { purchase: number; paid: number }> = {};
    bookings.filter((b) => b.supplierId === supplierId).forEach((b) => {
      map[b.purchaseCurrency] = map[b.purchaseCurrency] || { purchase: 0, paid: 0 };
      map[b.purchaseCurrency].purchase += Number(b.purchaseAmount || 0);
      map[b.purchaseCurrency].paid += bookingPurchasePaid(b);
    });
    return map;
  }

  let headers: string[] = [];
  let rows: (string | number)[][] = [];
  let totalsNode: React.ReactNode = null;

  if (type === 'sales') {
    headers = ['رقم الحجز', 'التاريخ', 'العميل', 'الخدمة', 'قيمة البيع', 'العملة', 'الحالة'];
    rows = bookings.map((b) => [b.number, fmtDate(b.date), getClientName(b.clientId), b.serviceType, fmt(b.saleAmount), b.saleCurrency, b.status]);
    const total: Record<string, number> = {};
    bookings.forEach((b) => total[b.saleCurrency] = (total[b.saleCurrency] || 0) + Number(b.saleAmount || 0));
    totalsNode = <TotalsLine map={total} />;
  } else if (type === 'purchases') {
    headers = ['رقم الحجز', 'التاريخ', 'المورد', 'الخدمة', 'قيمة الشراء', 'العملة', 'الحالة'];
    rows = bookings.map((b) => [b.number, fmtDate(b.date), getSupplierName(b.supplierId), b.serviceType, fmt(b.purchaseAmount), b.purchaseCurrency, b.status]);
    const total: Record<string, number> = {};
    bookings.forEach((b) => total[b.purchaseCurrency] = (total[b.purchaseCurrency] || 0) + Number(b.purchaseAmount || 0));
    totalsNode = <TotalsLine map={total} />;
  } else if (type === 'profit') {
    headers = ['رقم الحجز', 'التاريخ', 'بيع', 'شراء', 'صافي الربح (لنفس العملة)', 'العملة'];
    rows = bookings.filter((b) => b.saleCurrency === b.purchaseCurrency)
      .map((b) => [b.number, fmtDate(b.date), fmt(b.saleAmount), fmt(b.purchaseAmount), fmt(b.saleAmount - b.purchaseAmount), b.saleCurrency]);
    const total: Record<string, number> = {};
    bookings.filter((b) => b.saleCurrency === b.purchaseCurrency).forEach((b) => total[b.saleCurrency] = (total[b.saleCurrency] || 0) + (b.saleAmount - b.purchaseAmount));
    totalsNode = <TotalsLine map={total} />;
  } else if (type === 'bookings') {
    headers = ['رقم الحجز', 'التاريخ', 'الخدمة', 'العميل', 'المورد', 'الحالة'];
    rows = bookings.map((b) => [b.number, fmtDate(b.date), b.serviceType, getClientName(b.clientId), getSupplierName(b.supplierId), b.status]);
  } else if (type === 'clients') {
    headers = ['الكود', 'الاسم', 'الهاتف', 'العملة', 'عدد الحجوزات', 'المستحق'];
    rows = clients.map((c) => {
      const bal = clientBalance(c.id);
      const due = Object.entries(bal).map(([cur, v]) => money(v.sale - v.paid, cur)).join(' / ') || '-';
      return [c.code, c.name, c.phone || '-', c.currency, bookings.filter((b) => b.clientId === c.id).length, due];
    });
  } else if (type === 'suppliers') {
    headers = ['الكود', 'الاسم', 'النوع', 'العملة', 'عدد الحجوزات', 'المستحق'];
    rows = suppliers.map((s) => {
      const bal = supplierBalance(s.id);
      const due = Object.entries(bal).map(([cur, v]) => money(v.purchase - v.paid, cur)).join(' / ') || '-';
      return [s.code, s.name, s.type, s.currency, bookings.filter((b) => b.supplierId === s.id).length, due];
    });
  } else if (type === 'payments') {
    headers = ['التاريخ', 'النوع', 'الجهة', 'المبلغ', 'العملة', 'الطريقة', 'رقم الحجز'];
    const pays: any[] = [];
    bookings.forEach((b) => b.payments.forEach((p) => pays.push({
      ...p, bookingNumber: b.number, who: p.type === 'client' ? getClientName(b.clientId) : getSupplierName(b.supplierId),
    })));
    pays.sort((a, b) => a.date.localeCompare(b.date));
    rows = pays.map((p) => [fmtDate(p.date), p.type === 'client' ? 'تحصيل' : 'دفع', p.who, fmt(p.amount), p.currency, p.method, p.bookingNumber]);
  } else if (type === 'currency') {
    headers = ['العملة', 'إجمالي المبيعات', 'إجمالي المشتريات', 'صافي الربح'];
    rows = CURRENCIES.map((c) => {
      const sales = bookings.filter((b) => b.saleCurrency === c).reduce((s, b) => s + Number(b.saleAmount || 0), 0);
      const purchases = bookings.filter((b) => b.purchaseCurrency === c).reduce((s, b) => s + Number(b.purchaseAmount || 0), 0);
      return [c, fmt(sales), fmt(purchases), fmt(sales - purchases)];
    });
  }

  return (
    <div>
      <h2 className="section-title">التقارير</h2>
      <div className="section-sub">تقارير تفصيلية قابلة للتصفية والتصدير</div>

      <div className="card card-pad" style={{ marginBottom: 16 }}>
        <div className="filters" style={{ marginBottom: 12 }}>
          {REPORT_TYPES.map((r) => (
            <button key={r.id} className={`chip ${type === r.id ? 'active' : ''}`} onClick={() => setType(r.id)}>{r.label}</button>
          ))}
        </div>
        <div className="filters">
          <input type="date" value={filters.from} onChange={(e) => setFilters({ ...filters, from: e.target.value })} title="من تاريخ" />
          <input type="date" value={filters.to} onChange={(e) => setFilters({ ...filters, to: e.target.value })} title="إلى تاريخ" />
          <select value={filters.clientId} onChange={(e) => setFilters({ ...filters, clientId: e.target.value })}>
            <option value="">كل العملاء</option>{clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <select value={filters.supplierId} onChange={(e) => setFilters({ ...filters, supplierId: e.target.value })}>
            <option value="">كل الموردين</option>{suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
          <select value={filters.status} onChange={(e) => setFilters({ ...filters, status: e.target.value })}>
            <option value="">كل الحالات</option>{STATUSES.map((s) => <option key={s}>{s}</option>)}
          </select>
          <button className="btn btn-outline btn-sm" onClick={() => setFilters({ from: '', to: '', clientId: '', supplierId: '', serviceType: '', status: '' })}>مسح الفلاتر</button>
        </div>
      </div>

      <div className="card card-pad">
        <div className="flex" style={{ justifyContent: 'space-between', marginBottom: 12 }}>
          <h3 className="section-title" style={{ fontSize: 16, margin: 0 }}>{REPORT_TYPES.find((r) => r.id === type)?.label}</h3>
          <div className="flex gap8">
            <button className="btn btn-outline btn-sm" onClick={() => exportCSV(headers, rows)}>تصدير Excel (CSV)</button>
            <button className="btn btn-outline btn-sm" onClick={() => window.print()}>طباعة / PDF</button>
          </div>
        </div>
        {rows.length === 0 ? <div className="empty">لا توجد بيانات مطابقة لهذا التقرير</div> : (
          <div className="table-wrap">
            <table>
              <thead><tr>{headers.map((h) => <th key={h}>{h}</th>)}</tr></thead>
              <tbody>{rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j}>{c}</td>)}</tr>)}</tbody>
            </table>
          </div>
        )}
        {totalsNode}
      </div>
    </div>
  );
}

function TotalsLine({ map }: { map: Record<string, number> }) {
  const keys = Object.keys(map);
  if (!keys.length) return null;
  return (
    <div>
      <div className="divider" />
      <div className="flex gap8" style={{ flexWrap: 'wrap' }}>
        {keys.map((c) => <span key={c} className="pill">إجمالي {c}: {fmt(map[c])}</span>)}
      </div>
    </div>
  );
}
