'use client';
import { ReactNode } from 'react';

export default function Modal({
  title, onClose, children, actions,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  actions: { label: string; cls: string; onClick: () => void; disabled?: boolean }[];
}) {
  return (
    <div className="modal-bg" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal">
        <div className="modal-head">
          <h3>{title}</h3>
          <button className="icon-x" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">{children}</div>
        <div className="modal-foot">
          {actions.map((a, i) => (
            <button key={i} className={`btn ${a.cls}`} style={{ flex: 1 }} onClick={a.onClick} disabled={a.disabled}>
              {a.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
