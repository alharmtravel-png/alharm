'use client';
import { useEffect, useRef, useState } from 'react';
import { api } from '@/lib/api';
import { Booking, Client, Supplier, bookingSalePaid, bookingPurchasePaid } from '@/lib/types';
import { CURRENCIES, SERVICE_TYPES, STATUSES, money } from '@/lib/helpers';
import Modal from './Modal';
import StatusBadge from './StatusBadge';
import PaymentPill from './PaymentPill';
import { showToast } from './Toast';

const emptyForm = {
  date: new Date().toISOString().slice(0, 10),
  serviceType: SERVICE_TYPES[0],
  status: 'جديد',
  clientId: '',
  supplierId: '',
  saleAmount: '',
  saleCurrency: 'EGP',
  purchaseAmount: '',
  purchaseCurrency: 'EGP',
  notes: '',
  initialClientPaid: '',
  initialSupplierPaid: '',
};

export default function BookingsTab() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [statusFilter, setStatusFilter] = useState('');
  const [editing, setEditing] = useState<Booking | null | undefined>(undefined);
  const [detail, setDetail] = useState<Booking | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<any>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  function load() {
    api('/api/bookings').then(setBookings).catch(() => {});
    api('/api/clients').then(setClients).catch(() => {});
    api('/api/suppliers').then(setSuppliers).catch(() => {});
  }
  useEffect(load, []);

  function openForm(b?: Booking) {
    setEditing(b || null);
    setForm(b ? {
      date: b.date.slice(0, 10), serviceType: b.serviceType, status: b.status,
      clientId: b.clientId || '', supplierId: b.supplierId || '',
      saleAmount: String(b.saleAmount), saleCurrency: b.saleCurrency,
      purchaseAmount: String(b.purchaseAmount), purchaseCurrency: b.purchaseCurrency,
      notes: b.notes || '', initialClientPaid: '', initialSupplierPaid: '',
    } : emptyForm);
  }

  async function save() {
    try {
      const payload = { ...form, saleAmount: Number(form.saleAmount) || 0, purchaseAmount: Number(form.purchaseAmount) || 0 };
      if (editing) await api(`/api/bookings/${editing.id}`, { method: 'PUT', body: JSON.stringify(payload) });
      else await api('/api/bookings', { method: 'POST', body: JSON.stringify(payload) });
      showToast('تم الحفظ');
      setEditing(undefined);
      load();
    } catch (e: any) { showToast(e.message); }
  }

  async function remove(b: Booking) {
    if (!confirm(`حذف الحجز رقم ${b.number}؟`)) return;
    try { await api(`/api/bookings/${b.id}`, { method: 'DELETE' }); showToast('تم الحذف'); setDetail(null); load(); }
    catch (e: any) { showToast(e.message); }
  }

  async function openDetail(id: string) {
    const b = await api(`/api/bookings/${id}`);
    setDetail(b);
  }

  async function handleImport(file: File) {
    setImporting(true);
    setImportResult(null);
    try {
      const fd = new FormData();
      fd.append('file', file);
      const res = await fetch('/api/import', { method: 'POST', body: fd });
      const data = await res.json();
      setImportResult(data);
      showToast(`تم استيراد ${data.imported} حجز`);
      load();
    } catch (e: any) {
      showToast('فشل الاستيراد');
    } finally {
      setImporting(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  }

  const list = statusFilter ? bookings.filter((b) => b.status === statusFilter) : bookings;

  return (
    <div>
      <div className="toolbar">
        <div>
          <h2 className="section-title">الحجوزات</h2>
          <div className="section-sub mb0">إدارة عمليات البيع والشراء والدفعات</div>
        </div>
        <div className="flex gap8">
          <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" style={{ display: 'none' }}
            onChange={(e) => e.target.files?.[0] && handleImport(e.target.files[0])} />
          <button className="btn btn-outline" disabled={importing} onClick={() => fileRef.current?.click()}>
            {importing ? 'جارِ الاستيراد…' : '⬆ استيراد إكسيل'}
          </button>
          <button className="btn btn-gold" onClick={() => openForm()}>+ حجز جديد</button>
        </div>
      </div>

      {importResult && (
        <div className="card card-pad" style={{ marginBottom: 14 }}>
          <b>نتيجة الاستيراد:</b> تم استيراد {importResult.imported} حجز، تخطي {importResult.skipped}.
          {importResult.errors?.length > 0 && (
            <ul style={{ fontSize: 12.5, color: 'var(--bad)', marginTop: 8 }}>
              {importResult.errors.slice(0, 8).map((e: string, i: number) => <li key={i}>{e}</li>)}
            </ul>
          )}
        </div>
      )}

      <div className="filters" style={{ marginBottom: 14 }}>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="">كل الحالات</option>
          {STATUSES.map((s) => <option key={s}>{s}</option>)}
        </select>
      </div>

      <div className="card">
        {list.length === 0 ? <div className="empty">لا توجد حجوزات</div> : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>رقم الحجز</th><th>التاريخ</th><th>الخدمة</th><th>العميل</th><th>المورد</th><th>البيع</th><th>الحالة</th><th></th></tr></thead>
              <tbody>
                {list.map((b) => (
                  <tr key={b.id} style={{ cursor: 'pointer' }} onClick={() => openDetail(b.id)}>
                    <td className="mono">{b.number}</td><td>{b.date.slice(0, 10)}</td><td>{b.serviceType}</td>
                    <td>{b.client?.name || '-'}</td><td>{b.supplier?.name || '-'}</td>
                    <td>{money(b.saleAmount, b.saleCurrency)}</td>
                    <td><StatusBadge status={b.status} /></td>
                    <td onClick={(e) => e.stopPropagation()}>
                      <div className="flex gap8">
                        <button className="btn btn-outline btn-sm" onClick={() => openForm(b)}>تعديل</button>
                        <button className="btn btn-danger btn-sm" onClick={() => remove(b)}>حذف</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {editing !== undefined && (
        <Modal title={editing ? `تعديل حجز ${editing.number}` : 'حجز جديد'} onClose={() => setEditing(undefined)}
          actions={[{ label: 'حفظ', cls: 'btn-primary', onClick: save }]}>
          <div className="two-col">
            <div className="field"><label>التاريخ</label><input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></div>
            <div className="field"><label>نوع الخدمة</label>
              <select value={form.serviceType} onChange={(e) => setForm({ ...form, serviceType: e.target.value })}>
                {SERVICE_TYPES.map((s) => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div className="two-col">
            <div className="field"><label>العميل</label>
              <select value={form.clientId} onChange={(e) => setForm({ ...form, clientId: e.target.value })}>
                <option value="">بدون عميل</option>
                {clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div className="field"><label>المورد</label>
              <select value={form.supplierId} onChange={(e) => setForm({ ...form, supplierId: e.target.value })}>
                <option value="">بدون مورد</option>
                {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
          </div>
          <div className="two-col">
            <div className="field"><label>قيمة البيع</label><input type="number" step="0.01" value={form.saleAmount} onChange={(e) => setForm({ ...form, saleAmount: e.target.value })} /></div>
            <div className="field"><label>عملة البيع</label>
              <select value={form.saleCurrency} onChange={(e) => setForm({ ...form, saleCurrency: e.target.value })}>
                {CURRENCIES.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <div className="two-col">
            <div className="field"><label>قيمة الشراء</label><input type="number" step="0.01" value={form.purchaseAmount} onChange={(e) => setForm({ ...form, purchaseAmount: e.target.value })} /></div>
            <div className="field"><label>عملة الشراء</label>
              <select value={form.purchaseCurrency} onChange={(e) => setForm({ ...form, purchaseCurrency: e.target.value })}>
                {CURRENCIES.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
          </div>
          {!editing && (
            <div className="two-col">
              <div className="field"><label>دفعة أولية من العميل</label><input type="number" step="0.01" value={form.initialClientPaid} onChange={(e) => setForm({ ...form, initialClientPaid: e.target.value })} /></div>
              <div className="field"><label>دفعة أولية للمورد</label><input type="number" step="0.01" value={form.initialSupplierPaid} onChange={(e) => setForm({ ...form, initialSupplierPaid: e.target.value })} /></div>
            </div>
          )}
          <div className="field"><label>الحالة</label>
            <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
              {STATUSES.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
          <div className="field"><label>ملاحظات</label><textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
        </Modal>
      )}

      {detail && (
        <BookingDetail booking={detail} onClose={() => setDetail(null)}
          onChanged={() => { openDetail(detail.id); load(); }} onDelete={() => remove(detail)} />
      )}
    </div>
  );
}

function BookingDetail({ booking, onClose, onChanged, onDelete }: { booking: Booking; onClose: () => void; onChanged: () => void; onDelete: () => void }) {
  const [payForm, setPayForm] = useState<{ type: 'client' | 'supplier'; amount: string; currency: string; method: string } | null>(null);

  const salePaid = bookingSalePaid(booking);
  const purchasePaid = bookingPurchasePaid(booking);

  async function addPayment() {
    if (!payForm) return;
    try {
      await api(`/api/bookings/${booking.id}/payments`, {
        method: 'POST',
        body: JSON.stringify({ ...payForm, amount: Number(payForm.amount), date: new Date().toISOString().slice(0, 10) }),
      });
      showToast('تم تسجيل الدفعة');
      setPayForm(null);
      onChanged();
    } catch (e: any) { showToast(e.message); }
  }

  return (
    <Modal title={`حجز رقم ${booking.number}`} onClose={onClose} actions={[{ label: 'حذف الحجز', cls: 'btn-danger', onClick: onDelete }]}>
      <div className="flex gap8" style={{ marginBottom: 10 }}>
        <StatusBadge status={booking.status} />
        <span style={{ color: 'var(--muted)', fontSize: 13 }}>{booking.serviceType} · {booking.date.slice(0, 10)}</span>
      </div>
      <div className="two-col" style={{ marginBottom: 10 }}>
        <div className="kpi-card"><div className="kpi-label">البيع للعميل</div>
          <div className="kpi-row"><span>{money(booking.saleAmount, booking.saleCurrency)}</span></div>
          <div style={{ fontSize: 12, color: 'var(--muted)' }}>مدفوع {money(salePaid, booking.saleCurrency)} · متبقي {money(booking.saleAmount - salePaid, booking.saleCurrency)}</div>
        </div>
        <div className="kpi-card"><div className="kpi-label">الشراء من المورد</div>
          <div className="kpi-row"><span>{money(booking.purchaseAmount, booking.purchaseCurrency)}</span></div>
          <div style={{ fontSize: 12, color: 'var(--muted)' }}>مدفوع {money(purchasePaid, booking.purchaseCurrency)} · متبقي {money(booking.purchaseAmount - purchasePaid, booking.purchaseCurrency)}</div>
        </div>
      </div>
      <div className="flex gap8" style={{ marginBottom: 10 }}>
        <button className="btn btn-outline btn-sm" onClick={() => setPayForm({ type: 'client', amount: '', currency: booking.saleCurrency, method: 'نقدي' })}>+ دفعة من العميل</button>
        <button className="btn btn-outline btn-sm" onClick={() => setPayForm({ type: 'supplier', amount: '', currency: booking.purchaseCurrency, method: 'نقدي' })}>+ دفعة للمورد</button>
      </div>

      {payForm && (
        <div className="card card-pad" style={{ marginBottom: 12 }}>
          <div className="two-col">
            <div className="field"><label>المبلغ</label><input type="number" step="0.01" value={payForm.amount} onChange={(e) => setPayForm({ ...payForm, amount: e.target.value })} /></div>
            <div className="field"><label>طريقة الدفع</label>
              <select value={payForm.method} onChange={(e) => setPayForm({ ...payForm, method: e.target.value })}>
                {['نقدي', 'تحويل بنكي', 'بطاقة', 'أخرى'].map((m) => <option key={m}>{m}</option>)}
              </select>
            </div>
          </div>
          <div className="flex gap8">
            <button className="btn btn-primary btn-sm" onClick={addPayment}>حفظ الدفعة</button>
            <button className="btn btn-outline btn-sm" onClick={() => setPayForm(null)}>إلغاء</button>
          </div>
        </div>
      )}

      <h4 style={{ fontSize: 13, color: 'var(--muted)' }}>سجل الدفعات</h4>
      {booking.payments.length === 0 ? <div className="empty">لا توجد دفعات</div> : (
        <div className="table-wrap">
          <table>
            <thead><tr><th>النوع</th><th>المبلغ</th><th>الطريقة</th><th>التاريخ</th></tr></thead>
            <tbody>
              {booking.payments.map((p) => (
                <tr key={p.id}><td><PaymentPill type={p.type as any} /></td><td>{money(p.amount, p.currency)}</td><td>{p.method}</td><td>{p.date.slice(0, 10)}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Modal>
  );
}
