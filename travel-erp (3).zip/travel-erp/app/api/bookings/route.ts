import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/require-auth';
import { nextCode } from '@/lib/counters';

export async function GET(req: NextRequest) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const { searchParams } = new URL(req.url);
  const status = searchParams.get('status') || undefined;
  const serviceType = searchParams.get('serviceType') || undefined;
  const currency = searchParams.get('currency') || undefined;
  const from = searchParams.get('from') || undefined;
  const to = searchParams.get('to') || undefined;
  const clientId = searchParams.get('clientId') || undefined;
  const supplierId = searchParams.get('supplierId') || undefined;

  const where: any = {};
  if (status) where.status = status;
  if (serviceType) where.serviceType = serviceType;
  if (currency) where.OR = [{ saleCurrency: currency }, { purchaseCurrency: currency }];
  if (clientId) where.clientId = clientId;
  if (supplierId) where.supplierId = supplierId;
  if (from || to) {
    where.date = {};
    if (from) where.date.gte = new Date(from);
    if (to) where.date.lte = new Date(to + 'T23:59:59');
  }

  const bookings = await prisma.booking.findMany({
    where,
    include: { client: true, supplier: true, payments: true },
    orderBy: { date: 'desc' },
  });
  return NextResponse.json(bookings);
}

export async function POST(req: NextRequest) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const body = await req.json();
  if (!body.serviceType || !body.date) {
    return NextResponse.json({ error: 'التاريخ ونوع الخدمة مطلوبان' }, { status: 400 });
  }
  const number = await nextCode('booking', 'BK');
  const booking = await prisma.booking.create({
    data: {
      number,
      date: new Date(body.date),
      serviceType: body.serviceType,
      status: body.status || 'جديد',
      clientId: body.clientId || null,
      supplierId: body.supplierId || null,
      saleAmount: Number(body.saleAmount) || 0,
      saleCurrency: body.saleCurrency || 'EGP',
      purchaseAmount: Number(body.purchaseAmount) || 0,
      purchaseCurrency: body.purchaseCurrency || 'EGP',
      notes: body.notes || null,
    },
    include: { client: true, supplier: true, payments: true },
  });

  // optional initial payments captured at creation time (mirrors legacy UX)
  const initialPayments = [];
  if (Number(body.initialClientPaid) > 0 && body.clientId) {
    initialPayments.push(
      prisma.payment.create({
        data: {
          bookingId: booking.id,
          type: 'client',
          date: new Date(body.date),
          amount: Number(body.initialClientPaid),
          currency: body.saleCurrency || 'EGP',
          method: 'نقدي',
          notes: 'دفعة عند إنشاء الحجز',
        },
      })
    );
  }
  if (Number(body.initialSupplierPaid) > 0 && body.supplierId) {
    initialPayments.push(
      prisma.payment.create({
        data: {
          bookingId: booking.id,
          type: 'supplier',
          date: new Date(body.date),
          amount: Number(body.initialSupplierPaid),
          currency: body.purchaseCurrency || 'EGP',
          method: 'نقدي',
          notes: 'دفعة عند إنشاء الحجز',
        },
      })
    );
  }
  if (initialPayments.length) await Promise.all(initialPayments);

  const fresh = await prisma.booking.findUnique({
    where: { id: booking.id },
    include: { client: true, supplier: true, payments: true },
  });
  return NextResponse.json(fresh, { status: 201 });
}
