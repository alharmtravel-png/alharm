import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/require-auth';

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const { id } = await params;
  const body = await req.json();
  if (!body.type || !body.amount) {
    return NextResponse.json({ error: 'النوع والمبلغ مطلوبان' }, { status: 400 });
  }
  const payment = await prisma.payment.create({
    data: {
      bookingId: id,
      type: body.type,
      date: body.date ? new Date(body.date) : new Date(),
      amount: Number(body.amount),
      currency: body.currency || 'EGP',
      method: body.method || 'نقدي',
      notes: body.notes || null,
    },
  });
  return NextResponse.json(payment, { status: 201 });
}
