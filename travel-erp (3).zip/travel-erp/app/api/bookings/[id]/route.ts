import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/require-auth';

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const { id } = await params;
  const booking = await prisma.booking.findUnique({
    where: { id },
    include: { client: true, supplier: true, payments: { orderBy: { date: 'asc' } } },
  });
  if (!booking) return NextResponse.json({ error: 'غير موجود' }, { status: 404 });
  return NextResponse.json(booking);
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const { id } = await params;
  const body = await req.json();
  const booking = await prisma.booking.update({
    where: { id },
    data: {
      date: body.date ? new Date(body.date) : undefined,
      serviceType: body.serviceType,
      status: body.status,
      clientId: body.clientId || null,
      supplierId: body.supplierId || null,
      saleAmount: body.saleAmount !== undefined ? Number(body.saleAmount) : undefined,
      saleCurrency: body.saleCurrency,
      purchaseAmount: body.purchaseAmount !== undefined ? Number(body.purchaseAmount) : undefined,
      purchaseCurrency: body.purchaseCurrency,
      notes: body.notes,
    },
    include: { client: true, supplier: true, payments: true },
  });
  return NextResponse.json(booking);
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const { id } = await params;
  await prisma.booking.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
