import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/require-auth';
import { nextCode } from '@/lib/counters';
import * as XLSX from 'xlsx';

// Expected Excel columns (Arabic headers), one row per booking:
// التاريخ | نوع الخدمة | العميل | المورد | قيمة البيع | عملة البيع | قيمة الشراء | عملة الشراء | الحالة | ملاحظات
// Client/Supplier are matched by name; created automatically if not found.

function excelDateToISO(v: any): string | null {
  if (!v) return null;
  if (typeof v === 'number') {
    const d = XLSX.SSF.parse_date_code(v);
    if (!d) return null;
    return `${d.y}-${String(d.m).padStart(2, '0')}-${String(d.d).padStart(2, '0')}`;
  }
  const s = String(v).trim();
  // support dd/mm/yyyy or yyyy-mm-dd
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
  const m = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
  if (m) return `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  const parsed = new Date(s);
  if (!isNaN(parsed.getTime())) return parsed.toISOString().slice(0, 10);
  return null;
}

export async function POST(req: NextRequest) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;

  const form = await req.formData();
  const file = form.get('file') as File | null;
  if (!file) return NextResponse.json({ error: 'لم يتم إرفاق ملف' }, { status: 400 });

  const buf = Buffer.from(await file.arrayBuffer());
  const wb = XLSX.read(buf, { type: 'buffer', cellDates: false });
  const sheet = wb.Sheets[wb.SheetNames[0]];
  const rows: any[] = XLSX.utils.sheet_to_json(sheet, { defval: '' });

  const results = { imported: 0, skipped: 0, errors: [] as string[] };
  const clientCache = new Map<string, string>();
  const supplierCache = new Map<string, string>();

  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    const rowNum = i + 2; // account for header row
    const date = excelDateToISO(r['التاريخ']);
    const serviceType = String(r['نوع الخدمة'] || '').trim();
    if (!date || !serviceType) {
      results.skipped++;
      results.errors.push(`صف ${rowNum}: التاريخ أو نوع الخدمة مفقود`);
      continue;
    }

    let clientId: string | null = null;
    const clientName = String(r['العميل'] || '').trim();
    if (clientName) {
      if (clientCache.has(clientName)) {
        clientId = clientCache.get(clientName)!;
      } else {
        let client = await prisma.client.findFirst({ where: { name: clientName } });
        if (!client) {
          const code = await nextCode('client', 'CL');
          client = await prisma.client.create({ data: { code, name: clientName, currency: String(r['عملة البيع'] || 'EGP').trim() || 'EGP' } });
        }
        clientId = client.id;
        clientCache.set(clientName, client.id);
      }
    }

    let supplierId: string | null = null;
    const supplierName = String(r['المورد'] || '').trim();
    if (supplierName) {
      if (supplierCache.has(supplierName)) {
        supplierId = supplierCache.get(supplierName)!;
      } else {
        let supplier = await prisma.supplier.findFirst({ where: { name: supplierName } });
        if (!supplier) {
          const code = await nextCode('supplier', 'SP');
          supplier = await prisma.supplier.create({ data: { code, name: supplierName, currency: String(r['عملة الشراء'] || 'EGP').trim() || 'EGP' } });
        }
        supplierId = supplier.id;
        supplierCache.set(supplierName, supplier.id);
      }
    }

    try {
      const number = await nextCode('booking', 'BK');
      await prisma.booking.create({
        data: {
          number,
          date: new Date(date),
          serviceType,
          status: String(r['الحالة'] || 'جديد').trim() || 'جديد',
          clientId,
          supplierId,
          saleAmount: Number(r['قيمة البيع']) || 0,
          saleCurrency: String(r['عملة البيع'] || 'EGP').trim() || 'EGP',
          purchaseAmount: Number(r['قيمة الشراء']) || 0,
          purchaseCurrency: String(r['عملة الشراء'] || 'EGP').trim() || 'EGP',
          notes: String(r['ملاحظات'] || '').trim() || null,
        },
      });
      results.imported++;
    } catch (e: any) {
      results.skipped++;
      results.errors.push(`صف ${rowNum}: ${e.message || 'خطأ غير معروف'}`);
    }
  }

  return NextResponse.json(results);
}
