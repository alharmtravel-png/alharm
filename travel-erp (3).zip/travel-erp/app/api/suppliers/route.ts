import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/require-auth';
import { nextCode } from '@/lib/counters';

export async function GET() {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const suppliers = await prisma.supplier.findMany({ orderBy: { createdAt: 'desc' } });
  return NextResponse.json(suppliers);
}

export async function POST(req: NextRequest) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const body = await req.json();
  if (!body.name) return NextResponse.json({ error: 'اسم المورد مطلوب' }, { status: 400 });
  const code = await nextCode('supplier', 'SP');
  const supplier = await prisma.supplier.create({
    data: {
      code,
      name: body.name,
      type: body.type || 'مورد آخر',
      currency: body.currency || 'EGP',
      notes: body.notes || null,
    },
  });
  return NextResponse.json(supplier, { status: 201 });
}
