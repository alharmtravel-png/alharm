import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/require-auth';

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const { id } = await params;
  const supplier = await prisma.supplier.findUnique({
    where: { id },
    include: { bookings: { include: { payments: true }, orderBy: { date: 'desc' } } },
  });
  if (!supplier) return NextResponse.json({ error: 'غير موجود' }, { status: 404 });
  return NextResponse.json(supplier);
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const { id } = await params;
  const body = await req.json();
  const supplier = await prisma.supplier.update({
    where: { id },
    data: {
      name: body.name,
      type: body.type || 'مورد آخر',
      currency: body.currency || 'EGP',
      notes: body.notes || null,
    },
  });
  return NextResponse.json(supplier);
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const { id } = await params;
  const count = await prisma.booking.count({ where: { supplierId: id } });
  if (count > 0) {
    return NextResponse.json({ error: 'لا يمكن حذف مورد له حجوزات مسجلة' }, { status: 400 });
  }
  await prisma.supplier.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
