import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/require-auth';
import { nextCode } from '@/lib/counters';

export async function GET() {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const clients = await prisma.client.findMany({ orderBy: { createdAt: 'desc' } });
  return NextResponse.json(clients);
}

export async function POST(req: NextRequest) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const body = await req.json();
  if (!body.name) return NextResponse.json({ error: 'اسم العميل مطلوب' }, { status: 400 });
  const code = await nextCode('client', 'CL');
  const client = await prisma.client.create({
    data: {
      code,
      name: body.name,
      phone: body.phone || null,
      currency: body.currency || 'EGP',
      notes: body.notes || null,
    },
  });
  return NextResponse.json(client, { status: 201 });
}
