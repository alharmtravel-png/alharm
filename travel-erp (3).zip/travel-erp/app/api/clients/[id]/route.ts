import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/require-auth';

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const { id } = await params;
  const client = await prisma.client.findUnique({
    where: { id },
    include: { bookings: { include: { payments: true }, orderBy: { date: 'desc' } } },
  });
  if (!client) return NextResponse.json({ error: 'غير موجود' }, { status: 404 });
  return NextResponse.json(client);
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const { id } = await params;
  const body = await req.json();
  const client = await prisma.client.update({
    where: { id },
    data: {
      name: body.name,
      phone: body.phone || null,
      currency: body.currency || 'EGP',
      notes: body.notes || null,
    },
  });
  return NextResponse.json(client);
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const { id } = await params;
  const count = await prisma.booking.count({ where: { clientId: id } });
  if (count > 0) {
    return NextResponse.json({ error: 'لا يمكن حذف عميل له حجوزات مسجلة' }, { status: 400 });
  }
  await prisma.client.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
