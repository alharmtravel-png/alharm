import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/require-auth';
import bcrypt from 'bcryptjs';

export async function GET() {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const settings = await prisma.settings.findUnique({ where: { id: 1 } });
  return NextResponse.json({ companyName: settings?.companyName, darkMode: settings?.darkMode });
}

export async function PUT(req: NextRequest) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const body = await req.json();
  const data: any = {};
  if (body.companyName !== undefined) data.companyName = body.companyName;
  if (body.darkMode !== undefined) data.darkMode = body.darkMode;

  if (body.currentPassword && body.newPassword) {
    const settings = await prisma.settings.findUnique({ where: { id: 1 } });
    if (!settings) return NextResponse.json({ error: 'الإعدادات غير موجودة' }, { status: 400 });
    const valid = await bcrypt.compare(body.currentPassword, settings.passwordHash);
    if (!valid) return NextResponse.json({ error: 'كلمة المرور الحالية غير صحيحة' }, { status: 400 });
    data.passwordHash = await bcrypt.hash(body.newPassword, 10);
  }

  const settings = await prisma.settings.update({ where: { id: 1 }, data });
  return NextResponse.json({ companyName: settings.companyName, darkMode: settings.darkMode });
}
