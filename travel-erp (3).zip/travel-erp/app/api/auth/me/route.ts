import { NextResponse } from 'next/server';
import { getSessionFromCookies } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
  const ok = await getSessionFromCookies();
  const settings = await prisma.settings.findUnique({ where: { id: 1 } });
  const firstRun = !settings;
  if (!ok) return NextResponse.json({ authed: false, firstRun });
  return NextResponse.json({ authed: true, firstRun, companyName: settings?.companyName || 'شركتي للسياحة والسفر' });
}
