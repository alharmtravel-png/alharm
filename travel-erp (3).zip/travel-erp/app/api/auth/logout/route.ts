import { NextResponse } from 'next/server';
import { destroySessionCookie, SESSION_COOKIE } from '@/lib/auth';

export async function POST() {
  await destroySessionCookie();
  const res = NextResponse.json({ ok: true });
  res.cookies.delete(SESSION_COOKIE);
  return res;
}
