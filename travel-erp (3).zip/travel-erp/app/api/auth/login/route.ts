import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { createSession, SESSION_COOKIE, SESSION_MAX_AGE } from '@/lib/auth';
import bcrypt from 'bcryptjs';

export async function POST(req: NextRequest) {
  const { password } = await req.json();
  let settings = await prisma.settings.findUnique({ where: { id: 1 } });

  // First run: no settings yet -> this password becomes the system password
  if (!settings) {
    if (!password || password.length < 3) {
      return NextResponse.json({ error: 'كلمة المرور يجب ألا تقل عن 3 أحرف' }, { status: 400 });
    }
    const passwordHash = await bcrypt.hash(password, 10);
    settings = await prisma.settings.create({
      data: { id: 1, companyName: 'شركتي للسياحة والسفر', passwordHash },
    });
  } else {
    const valid = await bcrypt.compare(password || '', settings.passwordHash);
    if (!valid) {
      return NextResponse.json({ error: 'كلمة المرور غير صحيحة' }, { status: 401 });
    }
  }

  const token = await createSession();
  const res = NextResponse.json({ ok: true, firstRun: false, companyName: settings.companyName });
  res.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: true,
    sameSite: 'lax',
    path: '/',
    maxAge: SESSION_MAX_AGE,
  });
  return res;
}
