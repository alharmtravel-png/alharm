import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { requireAuth } from '@/lib/require-auth';

export async function GET(req: NextRequest) {
  const unauthed = await requireAuth();
  if (unauthed) return unauthed;
  const { searchParams } = new URL(req.url);
  const from = searchParams.get('from') || undefined;
  const to = searchParams.get('to') || undefined;
  const clientId = searchParams.get('clientId') || undefined;
  const supplierId = searchParams.get('supplierId') || undefined;
  const serviceType = searchParams.get('serviceType') || undefined;
  const status = searchParams.get('status') || undefined;

  const where: any = {};
  if (clientId) where.clientId = clientId;
  if (supplierId) where.supplierId = supplierId;
  if (serviceType) where.serviceType = serviceType;
  if (status) where.status = status;
  if (from || to) {
    where.date = {};
    if (from) where.date.gte = new Date(from);
    if (to) where.date.lte = new Date(to + 'T23:59:59');
  }

  const bookings = await prisma.booking.findMany({
    where,
    include: { client: true, supplier: true, payments: true },
    orderBy: { date: 'desc' },
  });
  const clients = await prisma.client.findMany();
  const suppliers = await prisma.supplier.findMany();

  return NextResponse.json({ bookings, clients, suppliers });
}
