'use client';
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import LoginScreen from '@/components/LoginScreen';
import Dashboard from '@/components/Dashboard';
import ClientsTab from '@/components/ClientsTab';
import SuppliersTab from '@/components/SuppliersTab';
import BookingsTab from '@/components/BookingsTab';
import ReportsTab from '@/components/ReportsTab';
import SettingsTab from '@/components/SettingsTab';
import Toast from '@/components/Toast';

const TABS = [
  { id: 'dashboard', label: 'الرئيسية' },
  { id: 'bookings', label: 'الحجوزات' },
  { id: 'clients', label: 'العملاء' },
  { id: 'suppliers', label: 'الموردين' },
  { id: 'reports', label: 'التقارير' },
  { id: 'settings', label: 'الإعدادات' },
];

export default function Home() {
  const [status, setStatus] = useState<'loading' | 'auth' | 'app'>('loading');
  const [firstRun, setFirstRun] = useState(false);
  const [companyName, setCompanyName] = useState('نظام محاسبة السياحة والسفر');
  const [tab, setTab] = useState('dashboard');
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    api('/api/auth/me').then((d) => {
      setFirstRun(d.firstRun);
      if (d.authed) { setCompanyName(d.companyName); setStatus('app'); }
      else setStatus('auth');
    }).catch(() => setStatus('auth'));

    const handler = () => setStatus('auth');
    window.addEventListener('unauthed', handler);
    return () => window.removeEventListener('unauthed', handler);
  }, []);

  async function logout() {
    await api('/api/auth/logout', { method: 'POST' });
    setStatus('auth');
  }

  if (status === 'loading') {
    return <div className="loading-screen"><div className="spinner" /> جارِ التحميل…</div>;
  }

  if (status === 'auth') {
    return (
      <LoginScreen
        firstRun={firstRun}
        onAuthed={(name) => { setCompanyName(name); setStatus('app'); setRefreshKey((k) => k + 1); }}
      />
    );
  }

  return (
    <div id="app">
      <header className="topbar">
        <div className="brand">
          🧾 <div>{companyName}<div className="brand-sub">إدارة الحجوزات والعملاء والموردين</div></div>
        </div>
        <div className="topbar-spacer" />
        <div className="topbar-actions">
          <button className="icon-btn-top" title="تسجيل الخروج" onClick={logout}>🔒</button>
        </div>
      </header>
      <nav className="tabs-row">
        {TABS.map((t) => (
          <button key={t.id} className={`tab-btn ${tab === t.id ? 'active' : ''}`} onClick={() => setTab(t.id)}>{t.label}</button>
        ))}
      </nav>
      <main className="content" key={refreshKey}>
        {tab === 'dashboard' && <Dashboard />}
        {tab === 'bookings' && <BookingsTab />}
        {tab === 'clients' && <ClientsTab />}
        {tab === 'suppliers' && <SuppliersTab />}
        {tab === 'reports' && <ReportsTab />}
        {tab === 'settings' && <SettingsTab onCompanyNameChange={setCompanyName} />}
      </main>
      <Toast />
    </div>
  );
}
